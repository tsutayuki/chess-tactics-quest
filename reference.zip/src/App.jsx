import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Chess } from "chess.js";

const GAME_STORAGE_KEY = "opening-wiki-game-v1";
const UI_STORAGE_KEY = "opening-wiki-ui-v1";

const FILES_WHITE = ["a", "b", "c", "d", "e", "f", "g", "h"];
const FILES_BLACK = ["h", "g", "f", "e", "d", "c", "b", "a"];
const RANKS_WHITE = [8, 7, 6, 5, 4, 3, 2, 1];
const RANKS_BLACK = [1, 2, 3, 4, 5, 6, 7, 8];

function safeParse(value) {
  if (!value) return null;
  try {
    return JSON.parse(value);
  } catch {
    return null;
  }
}

function clamp(value, min, max) {
  if (!Number.isFinite(value)) return min;
  return Math.min(max, Math.max(min, value));
}

function createInitialTimeline(chess) {
  return [{
    ply: 0,
    san: null,
    fen: chess.fen(),
    comment: "",
    moveNo: 0,
    side: "start",
    from: null,
    to: null,
  }];
}

function useGame() {
  const ref = useRef(new Chess());
  const persistedRef = useRef(undefined);

  if (persistedRef.current === undefined) {
    persistedRef.current = typeof window !== "undefined"
      ? safeParse(window.localStorage.getItem(GAME_STORAGE_KEY))
      : null;
  }

  const persisted = persistedRef.current;
  let initialPly = 0;

  const [timeline, setTimeline] = useState(() => {
    if (Array.isArray(persisted?.timeline) && persisted.timeline.length > 0) {
      const normalized = persisted.timeline.map((entry, index) => ({
        ply: typeof entry.ply === "number" ? entry.ply : index,
        san: entry.san ?? null,
        fen: entry.fen,
        comment: entry.comment ?? "",
        moveNo: entry.moveNo ?? Math.floor((index + 1) / 2),
        side: entry.side ?? (index % 2 === 1 ? "white" : "black"),
        from: entry.from ?? null,
        to: entry.to ?? null,
      })).filter((entry) => typeof entry.fen === "string");

      if (normalized.length > 0) {
        const safePly = clamp(
          Number.isFinite(persisted.ply) ? persisted.ply : normalized.length - 1,
          0,
          normalized.length - 1,
        );
        try {
          ref.current.load(normalized[safePly].fen);
          initialPly = safePly;
          return normalized;
        } catch {
          ref.current.reset();
        }
      }
    }
    return createInitialTimeline(ref.current);
  });

  const [ply, setPly] = useState(initialPly);
  const [fen, setFen] = useState(() => ref.current.fen());
  const [orientation, setOrientation] = useState(
    persisted?.orientation === "black" ? "black" : "white",
  );
  const [selected, setSelected] = useState(null);
  const [legal, setLegal] = useState(() => new Map());

  const status = useMemo(() => {
    const g = ref.current;
    const sideLabel = g.turn() === "w" ? "白番" : "黒番";
    if (g.isCheckmate()) return "チェックメイト";
    if (g.isStalemate()) return "ステイルメイト";
    if (g.isThreefoldRepetition()) return "千日手";
    if (g.isDraw()) return "引き分け";
    if (g.inCheck()) return `${sideLabel}の手番 - チェック`;
    return `${sideLabel}の手番`;
  }, [fen]);

  const movesList = useMemo(() => {
    const rows = [];
    for (let i = 1; i < timeline.length; i += 2) {
      rows.push({
        no: Math.floor((i + 1) / 2),
        white: timeline[i] ?? null,
        black: timeline[i + 1] ?? null,
      });
    }
    return rows;
  }, [timeline]);

  const last = useMemo(
    () => (ply > 0 && timeline[ply] ? { from: timeline[ply].from, to: timeline[ply].to } : null),
    [ply, timeline],
  );

  const syncBoard = () => {
    setFen(ref.current.fen());
    setSelected(null);
    setLegal(new Map());
  };

  const loadPly = (target) => {
    if (timeline.length === 0) return;
    const bounded = clamp(target, 0, timeline.length - 1);
    const entry = timeline[bounded];
    if (!entry) return;
    ref.current.load(entry.fen);
    setPly(bounded);
    syncBoard();
  };

  function highlightSquare(sq) {
    const g = ref.current;
    const piece = g.get(sq);
    const turn = g.turn();
    if (piece && piece.color === turn) {
      setSelected(sq);
      const moves = g.moves({ square: sq, verbose: true });
      setLegal(new Map(moves.map((m) => [m.to, m])));
      return true;
    }
    setSelected(null);
    setLegal(new Map());
    return false;
  }

  function clearSelection() {
    setSelected(null);
    setLegal(new Map());
  }

  function attemptMove(from, to) {
    if (!from || !to || from === to) return false;
    const g = ref.current;
    const moving = g.get(from);
    if (!moving) return false;

    const targetRank = parseInt(to[1], 10);
    const isPromo = moving.type === "p"
      && ((moving.color === "w" && targetRank === 8) || (moving.color === "b" && targetRank === 1));
    const mv = g.move({ from, to, promotion: isPromo ? "q" : undefined });
    if (!mv) return false;

    const newPly = ply + 1;
    setTimeline((prev) => {
      const nextEntry = {
        ply: newPly,
        san: mv.san,
        fen: g.fen(),
        comment: prev[newPly]?.comment ?? "",
        moveNo: Math.floor((newPly + 1) / 2),
        side: mv.color === "w" ? "white" : "black",
        from: mv.from,
        to: mv.to,
      };
      return [...prev.slice(0, newPly), nextEntry];
    });
    setPly(newPly);
    syncBoard();
    return true;
  }

  function onSquareClick(sq) {
    const g = ref.current;
    const piece = g.get(sq);

    if (!selected) {
      highlightSquare(sq);
      return;
    }

    if (selected === sq) {
      clearSelection();
      return;
    }

    const selPiece = g.get(selected);
    if (piece && selPiece && piece.color === selPiece.color) {
      highlightSquare(sq);
      return;
    }

    const moved = attemptMove(selected, sq);
    if (!moved) {
      clearSelection();
    }
  }

  function undo() {
    if (ply === 0) return;
    loadPly(ply - 1);
  }

  function reset() {
    ref.current.reset();
    setTimeline(createInitialTimeline(ref.current));
    setPly(0);
    syncBoard();
  }

  function goToPly(target) {
    loadPly(target);
  }

  function updateComment(targetPly, text) {
    setTimeline((prev) => prev.map((entry) => (
      entry.ply === targetPly ? { ...entry, comment: text } : entry
    )));
  }

  function listSquares() {
    const files = orientation === "white" ? FILES_WHITE : FILES_BLACK;
    const ranks = orientation === "white" ? RANKS_WHITE : RANKS_BLACK;
    const out = [];
    for (const r of ranks) {
      for (const f of files) out.push(`${f}${r}`);
    }
    return out;
  }

  function kingSquare(color) {
    const board = ref.current.board();
    for (let r = 0; r < 8; r += 1) {
      for (let c = 0; c < 8; c += 1) {
        const p = board[r][c];
        if (p && p.type === "k" && p.color === (color === "white" ? "w" : "b")) {
          const file = String.fromCharCode(97 + c);
          const rank = 8 - r;
          return `${file}${rank}`;
        }
      }
    }
    return null;
  }

  useEffect(() => {
    if (typeof window === "undefined") return;
    const payload = {
      timeline,
      ply,
      orientation,
    };
    window.localStorage.setItem(GAME_STORAGE_KEY, JSON.stringify(payload));
  }, [timeline, ply, orientation]);

  return {
    chess: ref.current,
    fen,
    orientation,
    setOrientation,
    selected,
    legal,
    last,
    status,
    movesList,
    onSquareClick,
    undo,
    reset,
    listSquares,
    kingSquare,
    timeline,
    ply,
    goToPly,
    updateComment,
    selectSquare: highlightSquare,
    attemptMove,
    clearSelection,
  };
}

const PIECE_THEME = {
  board: { light: "#f0d9b5", dark: "#b58863" },
  highlight: { select: "#f6f669", last: "#f3dc7a", check: "#e25b5b" },
  white: {
    fill: "#ffffff",
    stroke: "#1a1613",
    accent: "#ffffff",
  },
  black: {
    fill: "#000000",
    stroke: "#f5f1e8",
    accent: "#000000",
  },
pieces: {
    K: (palette, color) => (
      <g stroke={palette.stroke} strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" fill="none">
        <path d="M24 64h32v6H24z" fill={palette.accent} stroke="none" />
        <path d="M26 58h28v4H26z" fill={palette.fill} stroke="none" />
        <path d="M28 36c0-6.5 5.5-12 12-12s12 5.5 12 12v12c0 4-1.5 7.2-3.5 10H31.5C29.5 55.2 28 52 28 48z" fill={palette.fill} />
        <path d="M30 28h20l6 8H24z" fill={palette.fill} />
        <circle cx="40" cy="20" r="6" fill={palette.fill} />
        <path d="M40 8v10" />
        <path d="M34 14h12" />
        <path d="M32 48h16" />
        {color === 'black' ? (
          <rect x="32" y="42" width="16" height="2" fill={palette.stroke} stroke="none" />
        ) : null}
      </g>
    ),
    Q: (palette, color) => (
      <g stroke={palette.stroke} strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" fill="none">
        <path d="M24 64h32v6H24z" fill={palette.accent} stroke="none" />
        <path d="M26 58h28v4H26z" fill={palette.fill} stroke="none" />
        <path d="M22 36h36l-6 10H28z" fill={palette.fill} />
        <path d="M26 40c6 6 8 13 8 20v10h12V60c0-7 2-14 8-20" fill={palette.fill} />
        {[24,32,40,48,56].map((cx, idx) => (
          <circle key={cx} cx={cx} cy={24 + (idx === 2 ? -2 : 0)} r={idx === 2 ? 3.4 : 3} fill={palette.stroke} stroke="none" />
        ))}
        <path d="M32 50h16" />
        {color === 'black' ? (
          <rect x="30" y="44" width="20" height="2" fill={palette.stroke} stroke="none" />
        ) : null}
      </g>
    ),
    R: (palette, color) => (
      <g stroke={palette.stroke} strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" fill="none">
        <path d="M24 64h32v6H24z" fill={palette.accent} stroke="none" />
        <rect x="26" y="32" width="28" height="26" fill={palette.fill} stroke="none" />
        <path d="M26 20h6v6h4v-6h6v6h4v-6h6v12H26z" fill={palette.fill} stroke="none" />
        <path d="M30 44h20" />
        <path d="M30 50h20" />
        {color === 'black' ? (
          <>
            <rect x="30" y="34" width="4" height="10" fill={palette.stroke} stroke="none" />
            <rect x="38" y="34" width="4" height="10" fill={palette.fill} stroke="none" />
            <rect x="46" y="34" width="4" height="10" fill={palette.stroke} stroke="none" />
          </>
        ) : null}
      </g>
    ),
    B: (palette, color) => (
      <g stroke={palette.stroke} strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" fill="none">
        <path d="M24 64h32v6H24z" fill={palette.accent} stroke="none" />
        <path d="M28 58h24v4H28z" fill={palette.fill} stroke="none" />
        <path d="M28 44h24c4 4 6 8 6 12H22c0-4 2-8 6-12z" fill={palette.fill} stroke="none" />
        <path d="M40 12c6.5 4.2 10 9.5 10 16 0 7-4 12-10 18-6-6-10-11-10-18 0-6.5 3.5-11.8 10-16z" fill={palette.fill} stroke="none" />
        <path d="M33 23l14 14" />
        <circle cx="40" cy="10" r="3.4" fill={palette.stroke} stroke="none" />
        <path d="M40 6v5" />
        <path d="M35 12h10" />
        <path d="M40 18v4" />
        {color === 'black' ? (
          <path d="M30 50h20" strokeWidth="2" />
        ) : null}
      </g>
    ),
    N: (palette, color) => (
      <g stroke={palette.stroke} strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" fill={palette.fill}>
        <path d="M24 64h32v6H24z" fill={palette.accent} stroke="none" />
        <path d="M48 22c-6-6-13-7-20-3l3 7-9 12v18h24V44l-6-4 9-3z" />
        <path d="M34 30l-6 6" fill="none" />
        <circle cx="44" cy="28" r="3" fill={palette.stroke} stroke="none" />
        {color === 'black' ? (
          <circle cx="34" cy="40" r="2.5" fill={palette.stroke} stroke="none" />
        ) : null}
      </g>
    ),
    P: (palette, color) => (
      <g stroke={palette.stroke} strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" fill={palette.fill}>
        <path d="M24 64h32v6H24z" fill={palette.accent} stroke="none" />
        <path d="M28 58h24v4H28z" />
        <path d="M28 46h24c4 0 6 4 6 8H22c0-4 2-8 6-8z" />
        <circle cx="40" cy="28" r="9" />
        {color === 'black' ? (
          <path d="M32 52h16" />
        ) : null}
      </g>
    ),
  },
};


function PieceIcon({ piece }) {
  if (!piece) return null;
  const theme = PIECE_THEME;
  const color = piece === piece.toUpperCase() ? "white" : "black";
  const palette = color === "white" ? theme.white : theme.black;
  const Renderer = theme.pieces[piece.toUpperCase()];
  if (!Renderer) return null;
  return (
    <svg className="piece-svg" viewBox="0 0 80 80" role="presentation" focusable="false" aria-hidden="true">
      {Renderer(palette, color)}
    </svg>
  );
}

function Square({
  sq,
  piece,
  dark,
  selected,
  from,
  to,
  legal,
  capture,
  inCheck,
  isDragSource,
  isHover,
  canDrag,
  onClick,
  onPointerDown,
}) {
  return (
    <button
      type="button"
      className={`sq ${dark ? "sq--dark" : ""} ${selected ? "sq--sel" : ""} ${from || to ? "sq--last" : ""} ${inCheck ? "sq--check" : ""} ${isDragSource ? "sq--dragging" : ""} ${isHover ? "sq--hover" : ""} ${canDrag ? "sq--can-drag" : ""}`}
      onClick={onClick}
      onPointerDown={onPointerDown}
      aria-label={sq}
      title={sq}
    >
      {legal && (
        <span className={`hint ${capture ? "hint--ring" : "hint--dot"}`} />
      )}
      <span className="piece-wrap">
        {piece ? <PieceIcon piece={piece} /> : null}
      </span>
    </button>
  );
}

export default function App() {
  const {
    chess,
    fen,
    orientation,
    setOrientation,
    selected,
    legal,
    last,
    status,
    movesList,
    onSquareClick,
    undo,
    reset,
    listSquares,
    kingSquare,
    timeline,
    ply,
    goToPly,
    updateComment,
    selectSquare,
    attemptMove,
    clearSelection,
} = useGame();

  const uiPrefsRef = useRef();
  if (uiPrefsRef.current === undefined) {
    uiPrefsRef.current = typeof window !== "undefined"
      ? safeParse(window.localStorage.getItem(UI_STORAGE_KEY))
      : null;
  }
  const persistedUi = uiPrefsRef.current;

  const boardRef = useRef(null);
  const dragMetaRef = useRef(null);
  const attemptMoveRef = useRef(attemptMove);
  const selectSquareRef = useRef(selectSquare);
  const clearSelectionRef = useRef(clearSelection);

  useEffect(() => { attemptMoveRef.current = attemptMove; }, [attemptMove]);
  useEffect(() => { selectSquareRef.current = selectSquare; }, [selectSquare]);
  useEffect(() => { clearSelectionRef.current = clearSelection; }, [clearSelection]);

  const squares = useMemo(() => listSquares(), [orientation, listSquares, fen]);
  const turnColor = chess.turn() === "w" ? "white" : "black";
  const kSq = chess.inCheck() ? kingSquare(turnColor) : null;
  const files = orientation === "white" ? FILES_WHITE : FILES_BLACK;
  const ranks = orientation === "white" ? RANKS_WHITE : RANKS_BLACK;

  const [boardSize, setBoardSize] = useState(() => {
    if (persistedUi?.boardSize) {
      return clamp(Math.round(persistedUi.boardSize), 320, 640);
    }
    if (typeof window === "undefined") return 480;
    const vw = Math.min(window.innerWidth, 1200);
    return clamp(Math.round(vw * 0.52), 360, 560);
  });

  const [pieceScale, setPieceScale] = useState(() => {
    if (persistedUi?.pieceScale) {
      return clamp(Number(persistedUi.pieceScale), 0.7, 0.95);
    }
    return 0.84;
  });

  useEffect(() => {
    if (typeof window === "undefined") return;
    window.localStorage.setItem(UI_STORAGE_KEY, JSON.stringify({
      boardSize,
      pieceScale,
    }));
  }, [boardSize, pieceScale]);

  const theme = PIECE_THEME;
  const normalized = Math.round(boardSize / 8) * 8;
  const styleVars = {
    "--board-size": `${normalized}px`,
    "--piece-scale": pieceScale,
    "--square-size": `${normalized / 8}px`,
    "--sq-light": theme.board.light,
    "--sq-dark": theme.board.dark,
    "--sel": theme.highlight.select,
    "--last": theme.highlight.last,
    "--check": theme.highlight.check,
  };

  function pieceAt(sq) {
    const p = chess.get(sq);
    if (!p) return null;
    return p.color === "w" ? p.type.toUpperCase() : p.type;
  }

  const [drag, setDrag] = useState(() => ({
    active: false,
    from: null,
    piece: null,
    x: 0,
    y: 0,
    offsetX: 0,
    offsetY: 0,
  }));
  const [hoverSquare, setHoverSquare] = useState(null);

  const getSquareFromPoint = useCallback((clientX, clientY, rect, squareSize) => {
    if (!rect || squareSize <= 0) return null;
    const relX = clientX - rect.left;
    const relY = clientY - rect.top;
    if (relX < 0 || relY < 0 || relX >= rect.width || relY >= rect.height) return null;
    const fileIndex = Math.floor(relX / squareSize);
    const rankIndex = Math.floor(relY / squareSize);
    const file = files[fileIndex];
    const rank = ranks[rankIndex];
    if (file === undefined || rank === undefined) return null;
    return `${file}${rank}`;
  }, [files, ranks]);

  const beginDrag = (event, sq, pieceCode, canDragPiece) => {
    if (!pieceCode || !canDragPiece || event.button !== 0) {
      if (!pieceCode) {
        clearSelectionRef.current();
      }
      selectSquareRef.current(sq);
      return;
    }

    const boardRect = boardRef.current?.getBoundingClientRect();
    if (!boardRect) return;
    const squareSize = boardRect.width / 8;
    const index = squares.indexOf(sq);
    if (index === -1) return;
    const fileIdx = index % 8;
    const rankIdx = Math.floor(index / 8);
    const originX = boardRect.left + fileIdx * squareSize;
    const originY = boardRect.top + rankIdx * squareSize;

    dragMetaRef.current = {
      pointerId: event.pointerId,
      boardRect,
      squareSize,
      from: sq,
    };
    setDrag({
      active: true,
      from: sq,
      piece: pieceCode,
      x: event.clientX,
      y: event.clientY,
      offsetX: event.clientX - originX,
      offsetY: event.clientY - originY,
    });
    selectSquareRef.current(sq);
    setHoverSquare(sq);
    event.preventDefault();
  };

  useEffect(() => {
    if (!drag.active) return;

    const handleMove = (evt) => {
      const meta = dragMetaRef.current;
      if (!meta || evt.pointerId !== meta.pointerId) return;
      setDrag((prev) => {
        if (!prev.active) return prev;
        return { ...prev, x: evt.clientX, y: evt.clientY };
      });
      const target = getSquareFromPoint(evt.clientX, evt.clientY, meta.boardRect, meta.squareSize);
      setHoverSquare(target);
    };

    const finishDrag = (evt) => {
      const meta = dragMetaRef.current;
      if (!meta || evt.pointerId !== meta.pointerId) return;
      const target = getSquareFromPoint(evt.clientX, evt.clientY, meta.boardRect, meta.squareSize);
      dragMetaRef.current = null;
      setDrag({
        active: false,
        from: null,
        piece: null,
        x: 0,
        y: 0,
        offsetX: 0,
        offsetY: 0,
      });
      setHoverSquare(null);

      if (target) {
        const moved = attemptMoveRef.current(meta.from, target);
        if (!moved) {
          selectSquareRef.current(meta.from);
        }
      } else {
        selectSquareRef.current(meta.from);
      }
    };

    window.addEventListener("pointermove", handleMove);
    window.addEventListener("pointerup", finishDrag);
    window.addEventListener("pointercancel", finishDrag);
    return () => {
      window.removeEventListener("pointermove", handleMove);
      window.removeEventListener("pointerup", finishDrag);
      window.removeEventListener("pointercancel", finishDrag);
    };
  }, [drag.active, getSquareFromPoint]);

  const currentEntry = timeline[ply] ?? timeline[0];
  const commentLabel = currentEntry.ply === 0
    ? "初期局面"
    : `第${currentEntry.moveNo}手 ${currentEntry.side === "white" ? "白番" : "黒番"} / ${currentEntry.san}`;
  const commentDescription = currentEntry.ply === 0
    ? "ゲーム開始時の盤面"
    : `${currentEntry.side === "white" ? "白" : "黒"}の着手後の局面`;
  const orientationLabel = orientation === "white" ? "白視点" : "黒視点";
  const startHasComment = Boolean(timeline[0]?.comment?.trim());

  const renderMove = (entry) => {
    if (!entry) return null;
    const snippet = entry.comment?.trim();
    const snippetText = snippet && snippet.length > 28 ? `${snippet.slice(0, 28)}…` : snippet;
    const sideLabel = entry.side === "white" ? "白番" : "黒番";
    return (
      <button
        type="button"
        className={`move-btn ${entry.ply === ply ? "is-active" : ""}`}
        onClick={() => goToPly(entry.ply)}
      >
        <span className="move-label">
          <span>{entry.san}</span>
          <span className="move-meta">
            {sideLabel}
            {snippetText ? ` · ${snippetText}` : ""}
          </span>
        </span>
        {snippetText ? <span className="move-badge" title="コメントあり" /> : null}
      </button>
    );
  };

  return (
    <div className="page" style={styleVars}>
      <style>{CSS}</style>
      <header className="topbar"><span>オープニングWiki (β)</span></header>
      <main className="wrap">
        <section className="card board-card">
          <div className="toolbar">
            <button
              className="btn"
              onClick={() => setOrientation((o) => (o === "white" ? "black" : "white"))}
            >
              盤面反転（現在: {orientationLabel}）
            </button>
            <button className="btn" onClick={undo} disabled={ply === 0}>一手戻す</button>
            <button className="btn" onClick={reset}>初期化</button>
            <button className="btn" onClick={() => navigator.clipboard.writeText(fen)}>FENコピー</button>
            <div className="status">{status}</div>
          </div>

          <div className="sliders">
            <label>
              盤サイズ <span>{boardSize}px</span>
              <input
                type="range"
                min="360"
                max="640"
                step="2"
                value={boardSize}
                onChange={(e) => setBoardSize(clamp(parseInt(e.target.value, 10), 320, 640))}
              />
            </label>
            <label>
              駒サイズ <span>{Math.round(pieceScale * 100)}%</span>
              <input
                type="range"
                min="70"
                max="95"
                step="1"
                value={Math.round(pieceScale * 100)}
                onChange={(e) => setPieceScale(clamp(parseInt(e.target.value, 10) / 100, 0.7, 0.95))}
              />
            </label>
          </div>

          <div className="board-wrap">
            <div className="ranks">
              {ranks.map((rk) => (<div key={rk}>{rk}</div>))}
            </div>
            <div className="board" ref={boardRef}>
              {squares.map((sq, idx) => {
                const fileIdx = idx % 8;
                const rankIdx = Math.floor(idx / 8);
                const dark = (fileIdx + rankIdx) % 2 === 1;
                const pc = pieceAt(sq);
                const isSel = selected === sq;
                const isFrom = last?.from === sq;
                const isTo = last?.to === sq;
                const lm = legal.get(sq);
                const isLegal = Boolean(lm);
                const isCap = Boolean(lm?.flags && lm.flags.includes("c"));
                const inCheck = kSq === sq;
                const canDragPiece = pc
                  ? (pc === pc.toUpperCase() ? "white" : "black") === turnColor
                  : false;
                const isDragSource = drag.active && drag.from === sq;
                const isHover = drag.active && hoverSquare === sq;
                return (
                  <Square
                    key={sq}
                    sq={sq}
                    piece={pc}
                    dark={dark}
                    selected={isSel}
                    from={isFrom}
                    to={isTo}
                    legal={isLegal}
                    capture={isCap}
                    inCheck={inCheck}
                    isDragSource={isDragSource}
                    isHover={isHover}
                    canDrag={canDragPiece}
                    onClick={() => onSquareClick(sq)}
                    onPointerDown={(evt) => beginDrag(evt, sq, pc, canDragPiece)}
                  />
                );
              })}
            </div>
            <div className="files">
              {files.map((f) => (<div key={f}>{f}</div>))}
            </div>
          </div>
          {drag.active && drag.piece ? (
            <div
              className="drag-piece"
              style={{
                transform: `translate(${drag.x - drag.offsetX}px, ${drag.y - drag.offsetY}px)`,
              }}
            >
              <div className="piece-wrap piece-wrap--floating">
                <PieceIcon piece={drag.piece} />
              </div>
            </div>
          ) : null}
        </section>

        <aside className="card side">
          <div>
            <h2>ムーブ一覧</h2>
            <div className="moves">
              <div className="moves-start">
                <button
                  type="button"
                  className={`move-btn ${ply === 0 ? "is-active" : ""}`}
                  onClick={() => goToPly(0)}
                >
                  <span className="move-label">
                    <span>初期局面</span>
                    <span className="move-meta">白番がこれから指します</span>
                  </span>
                  {startHasComment ? <span className="move-badge" title="コメントあり" /> : null}
                </button>
              </div>
              <table>
                <thead>
                  <tr><th>#</th><th>白</th><th>黒</th></tr>
                </thead>
                <tbody>
                  {movesList.length === 0 ? (
                    <tr>
                      <td className="ctr">—</td>
                      <td className="empty" colSpan={2}>まだ指し手が記録されていません</td>
                    </tr>
                  ) : (
                    movesList.map((row) => (
                      <tr key={row.no}>
                        <td className="ctr">{row.no}</td>
                        <td>{row.white ? renderMove(row.white) : null}</td>
                        <td>{row.black ? renderMove(row.black) : null}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="comment-panel">
            <h2>コメント</h2>
            <div className="comment-meta">
              <span>{commentLabel}</span>
              <span>({commentDescription})</span>
            </div>
            <textarea
              className="comment-textarea"
              value={currentEntry.comment}
              onChange={(e) => updateComment(currentEntry.ply, e.target.value)}
              placeholder="この局面に関するプランや注意点をメモしましょう"
            />
            <div className="comment-hint">※ ブラウザに自動保存されます</div>
          </div>

          <div className="fen">
            <label htmlFor="fen-box">FEN</label>
            <div id="fen-box" className="fenbox">{fen}</div>
          </div>
        </aside>
      </main>
    </div>
  );
}

const CSS = `
:root{
  --bg:#f4f5f7; --text:#1b1f23; --muted:#667085; --card:#ffffff; --border:#d7dbe2;
  --primary:#111827; --accent:#2563eb; --accent-soft:rgba(37,99,235,0.12);
  --sq-light:#f0d9b5; --sq-dark:#b58863; --sel:#f6f669; --last:#f3dc7a; --check:#f0443a;
  --board-size:560px; --piece-scale:.84; --square-size: calc(var(--board-size)/8);
  --piece-size: calc(var(--square-size) * var(--piece-scale));
}
*{box-sizing:border-box}
html,body,#root{height:100%}
body{margin:0;background:var(--bg);color:var(--text);font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif}
.page{min-height:100vh}
.topbar{position:sticky;top:0;background:rgba(242,244,248,0.92);backdrop-filter:saturate(160%) blur(8px);padding:14px 20px;font-weight:700;font-size:20px;border-bottom:1px solid rgba(15,23,42,0.06);z-index:5;color:var(--primary)}
.wrap{max-width:1200px;margin:20px auto;display:grid;gap:22px;grid-template-columns:minmax(320px,1fr) 360px;align-items:start;padding:0 18px}
@media (max-width:980px){.wrap{grid-template-columns:1fr}}
.card{background:var(--card);border:1px solid var(--border);border-radius:18px;box-shadow:0 16px 36px rgba(15,23,42,0.08)}
.board-card{padding:16px;position:relative}
.toolbar{display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin:4px 4px 10px}
.btn{background:var(--primary);color:#fff;border:none;border-radius:12px;padding:9px 16px;font-size:14px;cursor:pointer;transition:background .16s ease,transform .16s ease}
.btn:hover:not(:disabled){background:#1f2937;transform:translateY(-1px)}
.btn:disabled{opacity:.55;cursor:not-allowed;background:#6b7280;transform:none}
.status{color:var(--accent);font-size:14px;font-weight:600;margin-left:auto}
.sliders{display:flex;gap:20px;flex-wrap:wrap;margin:12px 4px 16px}
.sliders label{display:flex;align-items:center;gap:10px;color:var(--muted);font-size:13px}
.sliders input[type=range]{accent-color:var(--accent);width:190px}
.board-wrap{display:grid;grid-template-columns:24px var(--board-size);grid-template-rows:var(--board-size) 22px;gap:8px;align-items:center;justify-content:center;margin:0 auto}
.ranks{display:grid;grid-template-rows:repeat(8,1fr);height:var(--board-size);color:var(--muted);font-size:12px;justify-items:end;align-items:center}
.files{display:grid;grid-template-columns:repeat(8,1fr);width:var(--board-size);color:var(--muted);font-size:12px;justify-items:center}
.board{width:var(--board-size);height:var(--board-size);display:grid;grid-template-columns:repeat(8,1fr);grid-template-rows:repeat(8,1fr);border-radius:16px;overflow:hidden;border:1px solid rgba(15,23,42,0.08);box-shadow:0 18px 40px rgba(15,23,42,0.14)}
.sq{position:relative;display:flex;align-items:center;justify-content:center;border:none;background:var(--sq-light);line-height:1;border-radius:0;margin:0;-webkit-tap-highlight-color:transparent;padding:0;cursor:pointer;transition:background .12s ease,box-shadow .12s ease}
.sq--dark{background:var(--sq-dark)}
.sq--sel{box-shadow:inset 0 0 0 3px var(--sel)}
.sq--last{box-shadow:inset 0 0 0 3px var(--last)}
.sq--check{box-shadow:inset 0 0 0 3px var(--check)}
.sq--hover{box-shadow:inset 0 0 0 3px rgba(37,99,235,0.35)}
.sq--hover::after{content:"";position:absolute;inset:6px;border:2px dashed rgba(37,99,235,0.45);border-radius:8px;pointer-events:none}
.sq--can-drag{cursor:grab !important}
.sq--dragging{cursor:grabbing !important}
.piece-wrap{width:var(--piece-size);height:var(--piece-size);display:flex;align-items:center;justify-content:center;transition:transform .12s ease,filter .12s ease}
.piece-wrap--floating{transform:scale(1.05)}
.piece-svg{width:100%;height:100%;filter:drop-shadow(0 1px 2px rgba(17,24,39,0.25))}
.sq--dragging::after{content:"";position:absolute;inset:20%;border-radius:50%;background:rgba(17,24,39,0.16);pointer-events:none;transform:scale(1.05)}
.sq--dragging .piece-wrap{opacity:.45;filter:grayscale(0.6);transform:scale(0.92)}
.hint{position:absolute;pointer-events:none}
.hint--dot{width:22%;height:22%;border-radius:50%;background:rgba(17,24,39,0.28)}
.hint--ring{width:72%;height:72%;border-radius:50%;border:3px solid rgba(17,24,39,0.35)}
.drag-piece{position:fixed;width:var(--square-size);height:var(--square-size);pointer-events:none;z-index:40;display:flex;align-items:center;justify-content:center}
.drag-piece .piece-wrap{width:var(--piece-size);height:var(--piece-size)}
.drag-piece .piece-svg{filter:drop-shadow(0 10px 20px rgba(15,23,42,0.28))}
.side{padding:18px 18px 22px;display:flex;flex-direction:column;gap:18px}
.side h2{font-size:16px;margin:0 0 10px;color:var(--primary)}
.moves{max-height:420px;overflow:auto;border:1px solid var(--border);border-radius:14px;background:#fff;box-shadow:inset 0 1px 4px rgba(15,23,42,0.05)}
.moves table{width:100%;border-collapse:collapse;font-size:14px}
.moves thead th{position:sticky;top:0;background:#eef3fb;border-bottom:1px solid var(--border);text-align:left;padding:10px 14px;font-weight:600;font-size:13px;color:var(--muted)}
.moves td,.moves th{padding:7px 14px;border-bottom:1px solid #e4ebf5;vertical-align:middle}
.moves td.ctr{width:48px;text-align:center;color:var(--muted);font-size:12px}
.moves td.empty{color:var(--muted);font-style:italic}
.move-btn{width:100%;display:flex;align-items:center;justify-content:space-between;gap:10px;background:transparent;border:none;padding:6px 0;font-size:14px;font-family:inherit;color:inherit;text-align:left;cursor:pointer;border-radius:10px;transition:background .16s ease,transform .16s ease}
.move-btn:hover{background:var(--accent-soft);transform:translateY(-1px)}
.move-btn.is-active{background:rgba(37,99,235,0.18);font-weight:600}
.move-label{display:flex;flex-direction:column;align-items:flex-start;gap:2px}
.move-meta{font-size:12px;color:var(--muted);letter-spacing:.01em}
.move-badge{width:8px;height:8px;border-radius:50%;background:var(--accent);flex-shrink:0}
.moves-start{padding:8px 14px 10px;border-bottom:1px solid var(--border);background:#eef3fb;border-radius:14px 14px 0 0}
.moves-start .move-btn{padding:6px 0}
.comment-panel{border:1px solid var(--border);border-radius:14px;padding:16px 18px;display:grid;gap:12px;background:#fff;box-shadow:0 12px 28px rgba(15,23,42,0.08)}
.comment-panel h2{font-size:16px;margin:0}
.comment-meta{font-size:13px;color:var(--muted);display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.comment-textarea{width:100%;min-height:150px;resize:vertical;font-family:inherit;font-size:14px;padding:10px 12px;border-radius:10px;border:1px solid #d1dae6;background:#fdfdfd;transition:border-color .15s ease,box-shadow .15s ease}
.comment-textarea:focus{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px rgba(37,99,235,0.18)}
.comment-hint{font-size:12px;color:var(--muted);text-align:right}
.fen{border:1px solid var(--border);border-radius:14px;padding:14px 18px;background:#fff;box-shadow:0 10px 24px rgba(15,23,42,0.06)}
.fen label{display:block;font-size:12px;color:var(--muted);margin:0 0 8px;text-transform:uppercase;letter-spacing:0.08em}
.fenbox{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;background:#f7f8fb;border:1px solid var(--border);padding:10px 12px;border-radius:10px;overflow-x:auto;font-size:13px}
@media (max-width:720px){
  .toolbar{flex-direction:column;align-items:flex-start}
  .status{margin-left:0}
  .sliders label{width:100%}
  .sliders input[type=range]{width:100%}
  .wrap{padding:0 14px}
}
`;
